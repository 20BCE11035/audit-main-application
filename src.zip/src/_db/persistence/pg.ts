import getPgPool from "../../persistence/pg";
export default getPgPool;
