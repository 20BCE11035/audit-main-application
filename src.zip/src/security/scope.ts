export interface Scope {
  projectId: string;
  environmentId: string;
  groupId?: string;
  targetId?: string;
}
