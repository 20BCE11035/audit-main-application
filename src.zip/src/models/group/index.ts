interface Group {
    id: string;
    name?: string;
}

export default Group;
