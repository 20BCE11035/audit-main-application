export interface EnterpriseToken {
    id: string;
    display_name: string;
    project_id: string;
    environment_id: string;
    group_id: string;
    view_log_action: string;
}
