export interface SavedExport {
    id: string;
    name: string;
    body: string;
    project_id: string;
    environment_id: string;
    group_id: string;
}
