export interface ActiveSearch {
    id: string;
    project_id: string;
    environment_id: string;
    group_id: string;
    saved_search_id: string;
}
